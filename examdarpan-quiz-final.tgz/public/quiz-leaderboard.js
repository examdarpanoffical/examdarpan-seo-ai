(function () {
  const path = location.pathname.replace(/\/+$/, '');
  if (path !== '/quiz' && path !== '/quiz.html' && path !== '') return;

  const esc = s => String(s ?? '').replace(/[&<>"']/g, c => ({
    '&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'
  }[c]));

  const fmtScore = n => Number.isFinite(Number(n))
    ? Number(n).toFixed(2).replace(/\.00$/, '')
    : '0';

  const fmtTime = sec => {
    sec = Math.max(0, Math.round(Number(sec || 0)));
    return `${Math.floor(sec / 60)}:${String(sec % 60).padStart(2, '0')}`;
  };

  const today = () => {
    const d = new Date();
    return `${d.getFullYear()}-${String(d.getMonth()+1).padStart(2,'0')}-${String(d.getDate()).padStart(2,'0')}`;
  };

  const css = `
  .ed-leaderboard{
    margin:22px 0 28px;
    padding:22px;
    border-radius:22px;
    background:linear-gradient(145deg,#fff,#f8fbff);
    border:1px solid #dbeafe;
    box-shadow:0 14px 40px rgba(15,23,42,.08)
  }
  .ed-lb-head{
    display:flex;
    align-items:center;
    justify-content:space-between;
    gap:12px;
    margin-bottom:16px
  }
  .ed-lb-eyebrow{
    font-size:11px;
    letter-spacing:1.2px;
    font-weight:900;
    color:#2563eb
  }
  .ed-lb-title{
    margin:4px 0 0;
    color:#0f172a;
    font-size:24px;
    line-height:1.2
  }
  .ed-lb-live{
    padding:7px 11px;
    border-radius:999px;
    background:#ecfdf5;
    color:#047857;
    font-size:11px;
    font-weight:900
  }
  .ed-lb-self{
    display:grid;
    grid-template-columns:auto 1fr auto;
    align-items:center;
    gap:12px;
    padding:14px;
    border-radius:17px;
    background:#eff6ff;
    border:1px solid #bfdbfe;
    margin-bottom:16px
  }
  .ed-lb-rank{
    font-weight:950;
    color:#1d4ed8;
    font-size:20px;
    min-width:48px;
    text-align:center
  }
  .ed-lb-self strong{
    display:block;
    color:#0f172a;
    font-size:15px
  }
  .ed-lb-self small{
    display:block;
    margin-top:3px;
    color:#64748b;
    line-height:1.5
  }
  .ed-lb-section-title{
    display:flex;
    align-items:center;
    justify-content:space-between;
    margin:4px 0 10px;
    color:#0f172a;
    font-weight:900
  }
  .ed-lb-section-title span{
    font-size:12px;
    color:#64748b;
    font-weight:700
  }
  .ed-lb-list{
    display:grid;
    gap:8px
  }
  .ed-lb-row{
    display:grid;
    grid-template-columns:42px 1fr auto auto;
    align-items:center;
    gap:10px;
    padding:11px 12px;
    border:1px solid #e2e8f0;
    border-radius:14px;
    background:#fff
  }
  .ed-lb-row.me{
    border-color:#93c5fd;
    background:#f8fbff
  }
  .ed-lb-pos{
    font-weight:950;
    color:#64748b;
    text-align:center
  }
  .ed-lb-name{
    font-weight:850;
    color:#0f172a;
    font-size:14px
  }
  .ed-lb-mini{
    display:block;
    margin-top:3px;
    font-size:10px;
    color:#64748b
  }
  .ed-lb-score{
    font-weight:950;
    color:#1d4ed8;
    text-align:right
  }
  .ed-lb-time{
    font-size:11px;
    color:#64748b;
    white-space:nowrap
  }
  .ed-lb-next{
    margin-top:14px;
    padding:12px 14px;
    border-radius:14px;
    background:#f8fafc;
    color:#475569;
    font-size:13px;
    line-height:1.5
  }
  @media(max-width:640px){
    .ed-leaderboard{padding:16px;margin:16px 0 22px}
    .ed-lb-title{font-size:20px}
    .ed-lb-row{grid-template-columns:32px 1fr auto}
    .ed-lb-time{display:none}
    .ed-lb-self{grid-template-columns:auto 1fr}
  }`;

  function injectStyle(){
    if(document.getElementById('ed-leaderboard-style')) return;
    const s=document.createElement('style');
    s.id='ed-leaderboard-style';
    s.textContent=css;
    document.head.appendChild(s);
  }

  async function getContext(){
    try{
      const appMod=await import(
        'https://www.gstatic.com/firebasejs/12.5.0/firebase-app.js'
      );
      const apps=appMod.getApps();
      if(!apps.length) return null;

      const app=appMod.getApp();
      const authMod=await import(
        'https://www.gstatic.com/firebasejs/12.5.0/firebase-auth.js'
      );
      const dbMod=await import(
        'https://www.gstatic.com/firebasejs/12.5.0/firebase-firestore.js'
      );

      return {
        auth:authMod.getAuth(app),
        db:dbMod.getFirestore(app),
        ...dbMod
      };
    }catch(e){
      console.warn('[ExamDarpan leaderboard] Firebase context failed',e);
      return null;
    }
  }

  function waitForAuth(auth){
    return new Promise(resolve=>{
      if(auth.currentUser) return resolve(auth.currentUser);

      let done=false;
      const finish=u=>{
        if(done)return;
        done=true;
        clearInterval(timer);
        clearTimeout(timeout);
        resolve(u||null);
      };

      const timer=setInterval(()=>{
        if(auth.currentUser) finish(auth.currentUser);
      },150);

      const timeout=setTimeout(()=>finish(null),10000);
    });
  }

  async function loadEntries(ctx, quizId){
    const {db,collection,getDocs,query,where,limit}=ctx;
    const mapRows=(snap)=>snap.docs.map(d=>({id:d.id,...d.data()}))
      .filter(x=>x.status==='submitted' && Number.isFinite(Number(x.score)))
      .sort((a,b)=>
        Number(b.score)-Number(a.score) ||
        Number(b.correct||b.right||0)-Number(a.correct||a.right||0) ||
        Number(a.wrong||0)-Number(b.wrong||0) ||
        Number(a.timeTakenSeconds||a.timeSpentSeconds||0)-Number(b.timeTakenSeconds||b.timeSpentSeconds||0) ||
        Number(a.submittedAtMs||0)-Number(b.submittedAtMs||0)
      );

    // quizAttempts is the authoritative submission record. Using it as the
    // primary source means the leaderboard still works even if a separate
    // quizLeaderboard write is rejected by Firestore rules.
    try{
      const snap=await getDocs(query(
        collection(db,'quizAttempts'),
        where('quizId','==',quizId),
        limit(1000)
      ));
      const raw=mapRows(snap);
      const latest=new Map();
      raw.forEach(row=>{
        const key=row.studentUid||row.id;
        const prev=latest.get(key);
        const rowMs=Number(row.submittedAtMs||0);
        const prevMs=Number(prev?.submittedAtMs||0);
        if(!prev || rowMs>=prevMs) latest.set(key,row);
      });
      const rows=[...latest.values()];
      if(rows.length)return rows;
    }catch(e){
      console.warn('[ExamDarpan leaderboard] quizAttempts read failed',e);
    }

    // Backward compatibility for older submissions that only exist in
    // quizLeaderboard.
    try{
      const snap=await getDocs(query(
        collection(db,'quizLeaderboard'),
        where('quizId','==',quizId),
        limit(1000)
      ));
      return mapRows(snap);
    }catch(e){
      console.warn('[ExamDarpan leaderboard] quizLeaderboard read failed',e);
      return [];
    }
  }

  function renderCard(result, user, rows){
    if(!result || !result.quizId || !rows.length) return;

    const me=rows.find(x=>x.studentUid===user.uid);
    if(!me) return;

    const rank=rows.findIndex(x=>x.studentUid===user.uid)+1;
    const top=rows.slice(0,10);

    injectStyle();

    const old=document.querySelector('.ed-leaderboard');
    if(old) old.remove();

    const card=document.createElement('section');
    card.className='ed-leaderboard';

    const maxMarks=Number(me.maxMarks||result.maxMarks||me.total||result.total||10);

    card.innerHTML=`
      <div class="ed-lb-head">
        <div>
          <div class="ed-lb-eyebrow">🏆 EXAM DARPAN LEADERBOARD</div>
          <h2 class="ed-lb-title">
            ${result.quizDate===today()?'आज की Ranking':'Test Ranking'}
          </h2>
        </div>
        <span class="ed-lb-live">● LIVE</span>
      </div>

      <div class="ed-lb-self">
        <div class="ed-lb-rank">#${rank}</div>
        <div>
          <strong>${esc(me.studentName||'Student')}</strong>
          <small>
            ${fmtScore(me.score)} / ${fmtScore(maxMarks)}
            · ${Number(me.correct||0)} सही
            · ${Number(me.wrong||0)} गलत
            · ${Number(me.skipped||0)} छोड़े
            · ⏱️ ${fmtTime(me.timeTakenSeconds||me.timeSpentSeconds)}
            ${me.negativeMarkingEnabled ? ` · −${fmtScore(me.negativeDeductionPerWrong||0)} / wrong` : ' · No negative marking'}
          </small>
        </div>
      </div>

      <div class="ed-lb-section-title">
        <span>TOP PERFORMERS</span>
        <span>${rows.length} students</span>
      </div>

      <div class="ed-lb-list">
        ${top.map((r,i)=>`
          <div class="ed-lb-row ${r.studentUid===user.uid?'me':''}">
            <div class="ed-lb-pos">
              ${i===0?'🥇':i===1?'🥈':i===2?'🥉':'#'+(i+1)}
            </div>
            <div class="ed-lb-name">
              ${esc(r.studentName||'Student')}
              ${r.studentUid===user.uid?'<span class="ed-lb-mini">YOU</span>':''}
              <span class="ed-lb-mini">
                ${Number(r.correct||0)} correct · ${Number(r.wrong||0)} wrong
              </span>
            </div>
            <div class="ed-lb-score">${fmtScore(r.score)}</div>
            <div class="ed-lb-time">⏱️ ${fmtTime(r.timeTakenSeconds)}</div>
          </div>
        `).join('')}
      </div>

      <div class="ed-lb-next">
        <b>Your Rank: #${rank}</b>
        · Ranking पहले Score, फिर Correct Answers, फिर कम Wrong और कम Time से तय होती है।
      </div>
    `;

    const resultBox=document.getElementById('quizResult');
    if(resultBox) resultBox.appendChild(card);
  }

  async function run(){
    const resultBox=document.getElementById('quizResult');
    if(!resultBox) return;

    const ctx=await getContext();
    if(!ctx) return;

    const user=await waitForAuth(ctx.auth);
    if(!user) return;

    let attempts=0;

    const check=async()=>{
      attempts++;

      const quizId=
        window.quizId ||
        document.body.dataset.quizId ||
        new URLSearchParams(location.search).get('id');

      if(!quizId){
        if(attempts<30) setTimeout(check,500);
        return;
      }

      const resultData={
        quizId,
        quizDate:window.quiz?.quizDate||today()
      };

      const rows=await loadEntries(ctx,quizId);

      if(rows.length){
        renderCard(resultData,user,rows);
        return;
      }

      if(attempts<30) setTimeout(check,500);
    };

    const observer=new MutationObserver(()=>{
      if(!resultBox.hidden){
        setTimeout(check,300);
      }
    });

    observer.observe(resultBox,{
      childList:true,
      subtree:true,
      attributes:true,
      attributeFilter:['hidden','class','style']
    });

    if(!resultBox.hidden) check();
  }

  if(document.readyState==='loading'){
    document.addEventListener('DOMContentLoaded',run,{once:true});
  }else{
    run();
  }
})();
